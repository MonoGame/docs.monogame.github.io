﻿using var game = new BasicCameraExample.BasicCameraExample();
game.Run();
